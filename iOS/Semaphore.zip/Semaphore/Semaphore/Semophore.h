//
//  Semophore.h
//  Semaphore
//
//  Created by autel on 17/7/27.
//  Copyright © 2017年 zhongjiasheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Semophore : NSObject

- (void)semaphore;

@end
